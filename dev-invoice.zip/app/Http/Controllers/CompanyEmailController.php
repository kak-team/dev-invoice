<?php

namespace App\Http\Controllers;

use App\CompanyEmail;
use Illuminate\Http\Request;

class CompanyEmailController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\CompanyEmail  $companyEmail
     * @return \Illuminate\Http\Response
     */
    public function show(CompanyEmail $companyEmail)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\CompanyEmail  $companyEmail
     * @return \Illuminate\Http\Response
     */
    public function edit(CompanyEmail $companyEmail)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\CompanyEmail  $companyEmail
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, CompanyEmail $companyEmail)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\CompanyEmail  $companyEmail
     * @return \Illuminate\Http\Response
     */
    public function destroy(CompanyEmail $companyEmail)
    {
        //
    }
}
