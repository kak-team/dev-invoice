<?php

namespace App\Http\Controllers;

use App\Invoice_income;
use Illuminate\Http\Request;

class Invoice_incomeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Invoice_income  $invoice_income
     * @return \Illuminate\Http\Response
     */
    public function show(Invoice_income $invoice_income)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Invoice_income  $invoice_income
     * @return \Illuminate\Http\Response
     */
    public function edit(Invoice_income $invoice_income)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Invoice_income  $invoice_income
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Invoice_income $invoice_income)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Invoice_income  $invoice_income
     * @return \Illuminate\Http\Response
     */
    public function destroy(Invoice_income $invoice_income)
    {
        //
    }
}
