<?php

namespace App\Http\Controllers;

use App\CompanyPhone;
use Illuminate\Http\Request;

class CompanyPhoneController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\CompanyPhone  $companyPhone
     * @return \Illuminate\Http\Response
     */
    public function show(CompanyPhone $companyPhone)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\CompanyPhone  $companyPhone
     * @return \Illuminate\Http\Response
     */
    public function edit(CompanyPhone $companyPhone)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\CompanyPhone  $companyPhone
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, CompanyPhone $companyPhone)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\CompanyPhone  $companyPhone
     * @return \Illuminate\Http\Response
     */
    public function destroy(CompanyPhone $companyPhone)
    {
        //
    }
}
