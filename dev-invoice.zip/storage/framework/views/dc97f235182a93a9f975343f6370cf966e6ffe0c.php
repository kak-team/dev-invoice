<?php $__env->startSection('content'); ?>
<style>
.font {
    font-family: battambang, Roboto,-apple-system,BlinkMacSystemFont;
}
.fixed-sn main {
    padding-top: 2.5rem;
}
.company-name {
    font-family: moul, Roboto;
}
.company-en-name {
    font-family:Roboto;
    font-weight: 600;
}
</style>
<link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet">
<div class="fixed-sn white-skin js-focus-visible">
    <main class="bg-white p-4">
        <div class="container-fluid">
            <!-- First row -->
            <div class="row white z-depth-1 mb-5">

                <!-- Navigation -->
                <div class="col-md-6">
                    <h4 class="h4-responsive mt-3">Receipt</h4>
                </div>

                <div class="col-md-6 text-md-right">
                    <a href="#" class="btn btn-secondary waves-effect waves-light">Pay now</a>
                    <a href="#" class="btn btn-primary waves-effect waves-light"><i class="fa fa-print left"></i> Print</a>
                </div>
                <!-- /.Navigation -->

            </div>
            <!-- /.First row -->

            <section class="invoice font row mb-r">
            <?php $__currentLoopData = $values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-12">
                
                    <!-- company logo-->
                    <div class="row p-1 d-flex align-items-center">
                        <div class="col p-3">
                            <img class="img-fluid" src="<?php echo e(URL::asset('/images/'. $value->logo)); ?>"/>
                        </div>
                        <div class="col col-md-10">
                            <h2 class="company-name"> <?php echo e($value->name); ?> </h2>
                            <h2 class="company-en-name font-wieght-600"> <?php echo e($value->en_name); ?> </h2>   
                        </div>
                    </div>
                    <hr size="30">   
                    <!-- First row -->
                    <div class="row invoice-data">
                        
                        <div class="col-7">
                            <p><strong>អតិថិជន / Customer:</strong></p>
                            <table class="">
                                <tr class="">
                                    <td>ឈ្មោះក្រុមហ៊ុន</td>
                                    <td>: </td>
                                    <td>Name Here</td>
                                </tr>
                                <tr class="">
                                    <td>Company Name</td>
                                    <td>: </td>
                                    <td>Name Here</td>
                                </tr>
                                <tr class="">
                                    <td>លេខអតប / VAT No.</td>
                                    <td>: </td>
                                    <td>00000000000000000</td>
                                </tr>
                                <tr class="">
                                    <td>ទំនាក់ទំនង​/ Contact</td>
                                    <td>: </td>
                                    <td>00000000000000000</td>
                                </tr>
                                <tr class="">
                                    <td>ទូរសព្ទ / Tel</td>
                                    <td>: </td>
                                    <td>00000000000000000</td>
                                </tr>
                                <tr class="">
                                    <td>អុីម៉ែល / E-mail</td>
                                    <td>: </td>
                                    <td>00000000000000000</td>
                                </tr>
                                <tr class="">
                                    <td>អាសយដ្ឋាន / Address</td>
                                    <td>: </td>
                                    <td>00000000000000000</td>
                                </tr>
                            </table>
                        </div>
                        <div class="col text-right">
                            <!-- <p><strong>វិក័យប័ត្រពន្ធ / Tax Invoice</strong></p> -->
                            <table class="d-flex justify-content-end">
                                <tr>
                                    <td>លេខអតប / VAT No</td>
                                    <td>:</td>
                                    <td><?php echo e($value->register_number); ?></td>
                                </tr>
                                <tr>
                                    <td>លេខបង្កាន់ដៃទទួលប្រាក់ / Receipt No</td>
                                    <td>:</td>
                                    <td>#000000</td>
                                </tr>
                                <tr>
                                    <td>ថ្ងៃចេញបង្កាន់ដៃ / Issued Date</td>
                                    <td>:</td>
                                    <td> 12/12/2019</td>
                                </tr>
                                <tr>
                                    <td>ចេញដោយ / Issued by</td>
                                    <td>:</td>
                                    <td> Heng Seyha</td>
                                </tr>
                                
                            </table>
                        </div>
                        
                    </div>
                    <!-- ./First row -->
                    
               
                    <!-- Second row -->
                    <?php echo $__env->make('print.receipt', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <!-- /.Third row -->

                </div>
                <!---footer invoice-->
                <div class="col-md-12 footer-invoice pt-5 mt-5">
                    <div class="row pt-5">
                        <div class="col d-flex justify-content-center">
                            <div class="col-md-7 text-center">
                                <hr/>
                                <h6 class="mt-3">ហត្ថលេខា និងឈ្មោះអ្នកទិញ​ <br/><small>Customer's Signature & Name</small></h6>
                            </div>
                        </div>
                        <div class="col d-flex justify-content-center">
                            <div class="col-md-7 text-center">
                                <hr/>
                                <h6 class="mt-3">ហត្ថលេខា និងឈ្មោះអ្នកលក់ <br/><small>Seller's Signature & Name</small></h6>
                            </div>
                        </div>
                    </div>
                    <div class="row footer-note mt-5">
                        <div class="note​​ col-md-12">
                            <small>
                               <p>សំគាល់៖ </p>
                               <p>Note: </p>
                            </small>
                        </div>
                        <div class="col-md-12">
                            <hr>
                        </div>    
                        <div class="address col-md-12 text-center pb-3">
                            <small class="companyinfo">
                                <?php $__currentLoopData = $khaddress; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <p>ផ្ទះលេខ<?php echo e($address->house_number); ?>  ផ្លូវលេខ<?php echo e($address->street_number); ?>  សង្កាត់<?php echo e($address->commune); ?>  ខ័ណ្ឌ<?php echo e($address->districk); ?>  រាជធានី<?php echo e($address->province); ?>  កម្ពុជា / លេខទំនាក់ទំនង៖​ 
                                        <?php $__currentLoopData = $phones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $phone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                            <?php echo e($phone->phone); ?>

                                            <?php if(!$loop->last): ?>
                                                /
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        អុីម៉ែល៖ 
                                        <?php $__currentLoopData = $emails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $email): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                            <?php echo e($email->email); ?>

                                            <?php if(!$loop->last): ?>
                                                /
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </p>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $enaddress; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $en): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <p><?php echo e($en->house_number); ?>, Street <?php echo e($en->street_number); ?>, Sangkat <?php echo e($en->commune); ?>, Khan <?php echo e($en->districk); ?>, City <?php echo e($en->province); ?>, Cambodia. Hoteline:
                                    <?php $__currentLoopData = $phones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $phone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                            <?php echo e($phone->phone); ?>

                                            <?php if(!$loop->last): ?>
                                                /
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        , E-mail:  
                                        <?php $__currentLoopData = $emails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $email): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                            <?php echo e($email->email); ?>

                                            <?php if(!$loop->last): ?>
                                                /
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </p> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </small>
                        </div>
                    </div>

                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </section>
        </div>

    </main>
</div>   
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\dev-invoice\resources\views/print/header.blade.php ENDPATH**/ ?>