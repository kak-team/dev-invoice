<div class="card">
        <div class="card-header bg-info header-elements-inline p-2">
            <h6 class="card-title font-weight-semibold font-weight-bold">Create Payment: Current Balance $ <?php echo e($payments_history[0]->previous_balance); ?></h6>
            <div class="header-elements">
                <div class="list-icons">
                    <a class="list-icons-item" data-action="collapse"></a>
                </div>
            </div>
        </div>
        
        
            <div class="card-body p-2" style="">
                <form method="post" action="<?php echo e(action('Invoice_airticket_listController@update_payment')); ?>">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="payment_list_id" value="<?php echo e($payment_list_id); ?>">
                    <div class="row">
                        <div class="col">
                            <!-- Medium input -->
                            <div class="md-form text-left md-top-2">
                                <input type="number" min="1" max="<?php echo e($payments_history[0]->previous_balance); ?>" id="p_paymentPrice" class="form-control font-weight-bold" name="payment_price" value="<?php echo e($payments_history[0]->new_payment); ?>" step="0.01">
                                <label for="p_paymentPrice" class="text-nowrap active">Payment Price</label>
                            </div>
                        </div>
                        <div class="col">
                            <div class="md-form text-left">
                                <input type="date" id="p_paymentDate" class="form-control font-weight-bold" name="payment_date" value="<?php echo e(date('Y-m-d',strtotime($payments_history[0]->issue_date))); ?>">
                                <label for="p_paymentDate" class="text-nowrap active plabel">Payment Date</label>
                            </div>
                        </div>
                        <div class="col">
                            
                            <!--Blue select-->
                            <div class="md-form text-left">
                                <select class="mdb-select md-form colorful-select dropdown-primary" id="PE_payment_method" name="payment_method">
                                    <?php $__currentLoopData = $payment_method; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($method->id); ?>" <?php echo e(($method->id == $payments_history[0]->payment_method_id ? 'selected':'')); ?>><?php echo e($method->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <label for="P_payment_method" class="text-nowrap active plabel" style="font-size:13px">Payment Method</label>
                            </div>
                            

                        </div>
                        <div class="col">
                            <div class="md-form text-left md-top-2">
                                <input type="text" id="payment_status" class="form-control font-weight-bold" name="payment_status" value="<?php echo e($payments_history[0]->status); ?>" >
                                <label for="payment_status" class="text-nowrap active">Payment Status</label>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="md-form text-left m-0">
                                <input type="text" id="p_paymentDescription" class="form-control font-weight-bold" name="payment_description" value="<?php echo e($payments_history[0]->description); ?>" >
                                <label for="p_paymentDescription" class="text-nowrap active">Payment Description</label>
                            </div>  
                        </div>
                        <div class="col-lg-12">
                            <button class="btn btn-danger legitRipple waves-effect waves-light modal_fix_overflow" type="button" data-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-success legitRipple waves-effect waves-light">Save Change<i class="icon-circle-right2 ml-2"></i></button>
                        </div>
                    </div>
                </form>
            </div>
        
        
    </div><?php /**PATH C:\wamp64\www\dev-invoice\resources\views/invoice_airticket_list/edit_payment.blade.php ENDPATH**/ ?>