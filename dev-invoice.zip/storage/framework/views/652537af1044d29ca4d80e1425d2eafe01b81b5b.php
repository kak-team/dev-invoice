<?php $__env->startSection('content'); ?>
<style>
.font {
    font-family: battambang, Roboto,-apple-system,BlinkMacSystemFont;
}
.fixed-sn main {
    padding-top: 2.5rem;
}
.company-name {
    font-family: moul, Roboto;
}
.company-en-name {
    font-family:Roboto;
    font-weight: 600;
}
</style>
<link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet">
<div class="fixed-sn white-skin js-focus-visible container-fluid bg-white">
            <section class="invoice font row">
                <div class="col-md-12 d-flex p-3">
                        <div class="col">
                            <!-- Material form contact -->
                            <div class="card">
                                <small class="card-header info-color white-text text-center p-1">
                                    Filter by date
                                </small>
                                <!--Card content-->
                                <div class="card-body pb-0">
                                    <!-- Form -->
                                    <form class="text-center" style="color: #757575;" action="#!">
                                        <div class="row pt-3">
                                            <div class="col">
                                                <!-- from date -->
                                                <div class="md-form text-left">
                                                    <input type="date" id="fromDate" class="form-control font-weight-light" name="from_date" value="2019-12-24">
                                                    <label for="fromDate" class="text-nowrap active plabel">From Date</label>
                                                </div>
                                            </div>
                                            <div class="col">
                                                <!-- To date -->
                                                <div class="md-form text-left">
                                                    <input type="date" id="toDate" class="form-control font-weight-light" name="to_date" value="2019-12-24">
                                                    <label for="toDate" class="text-nowrap active plabel">To Date</label>
                                                </div>
                                            </div>
                                        </div> 
                                        <div class="row">
                                            <div class="md-form">
                                                <input placeholder="Selected date" type="text" id="date-picker-example" class="form-control datepicker">
                                                <label for="date-picker-example">Try me...</label>
                                            </div>
                                        </div>
                                    </form>
                                    <!-- Form -->

                                </div>
                            </div>
                            <!-- Material form contact -->
                        </div>
                        <div class="col">
                            <!-- Material form contact -->
                            <div class="card">
                                <small class="card-header success-color white-text text-center p-1">
                                    Filter by stutus
                                </small>
                                <!--Card content-->
                                <div class="card-body pb-0">
                                    <!-- Form -->
                                    <form class="text-center" style="color: #757575;" action="#!">
                                        <div class="row pt-3">
                                            <div class="col">
                                                <!-- from date -->
                                                <div class="md-form text-left">
                                                    <input type="date" id="fromDate" class="form-control font-weight-light" name="from_date" value="2019-12-24">
                                                    <label for="fromDate" class="text-nowrap active plabel">From Date</label>
                                                </div>
                                            </div>
                                            <div class="col">
                                                <!-- To date -->
                                                <div class="md-form text-left">
                                                    <input type="date" id="toDate" class="form-control font-weight-light" name="to_date" value="2019-12-24">
                                                    <label for="toDate" class="text-nowrap active plabel">To Date</label>
                                                </div>
                                            </div>
                                        </div> 
                                        <div class="row">
                                            <div class="md-form">
                                                <input placeholder="Selected date" type="text" id="date-picker-example" class="form-control datepicker">
                                                <label for="date-picker-example">Try me...</label>
                                            </div>
                                        </div>
                                    </form>
                                    <!-- Form -->

                                </div>
                            </div>
                        </div>
                        <div class="col">
                            <!-- Material form contact -->
                            <div class="card">
                                <small class="card-header success-color white-text text-center p-1">
                                    Filter by specifect invoice
                                </small>
                                <!--Card content-->
                                <div class="card-body pb-0">
                                    <!-- Form -->
                                    <form class="text-center" style="color: #757575;" action="#!">
                                        <div class="row pt-3">
                                            <div class="col">
                                                <!-- from date -->
                                                <div class="md-form text-left">
                                                    <input type="date" id="fromDate" class="form-control font-weight-light" name="from_date" value="2019-12-24">
                                                    <label for="fromDate" class="text-nowrap active plabel">From Date</label>
                                                </div>
                                            </div>
                                            <div class="col">
                                                <!-- To date -->
                                                <div class="md-form text-left">
                                                    <input type="date" id="toDate" class="form-control font-weight-light" name="to_date" value="2019-12-24">
                                                    <label for="toDate" class="text-nowrap active plabel">To Date</label>
                                                </div>
                                            </div>
                                        </div> 
                                        <div class="row">
                                            <div class="md-form">
                                                <input placeholder="Selected date" type="text" id="date-picker-example" class="form-control datepicker">
                                                <label for="date-picker-example">Try me...</label>
                                            </div>
                                        </div>
                                    </form>
                                    <!-- Form -->

                                </div>
                            </div>
                        </div>
                </div>
                <!--end header report-->

                <div class="col-md-12">
                    <!-- Second row -->
                        <div class="row mt-2">
                            <div class="col-md-12">
                                <div class="text-center pt-5">
                                    <h1>Report</h1>
                                </div>
                                </span>
                                <table class="table table-striped">
                                    <thead class="bg-info">
                                        <tr>
                                            <th class="text-nowrap small">Issued Date</th>
                                            <th class="text-nowrap small">Pay Date</th>
                                            <th class="text-center text-nowrap small">Invoice Number</th>
                                            <th class="text-center text-nowrap small">Provider Name</th>
                                            <th class="text-center text-nowrap small">Service Type</th>
                                            <th class="text-center text-nowrap small">Company Name</th>
                                            <th class="text-center text-nowrap small">Contact Name</th>
                                            <th class="text-center text-nowrap small">Total</th>
                                            <th class="text-center text-nowrap small">Deposit</th>
                                            <th class="text-center text-nowrap small">Balence</th>
                                            <th class="text-center text-nowrap small">Sale By</th>
                                            <th class="text-center text-nowrap small">Status</th>
                                            <th class="text-center text-nowrap small">Reissue To</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr class="small">
                                            <td class="col-md-9"><em>Baked Rodopa Sheep Feta</em></h4></td>
                                            <td class="col-md-1" style="text-align: center"> 2 </td>
                                            <td class="col-md-1 text-center">$13</td>
                                            <td class="col-md-1 text-center">$26</td>
                                            <td class="col-md-1 text-center">$26</td>
                                            <td class="col-md-1 text-center">$26</td>
                                            <td class="col-md-1 text-center">$26</td>
                                            <td class="col-md-1 text-center">$26</td>
                                            <td class="col-md-1 text-center">$26</td>
                                            <td class="col-md-1 text-center">$26</td>
                                            <td class="col-md-1 text-center">$26</td>
                                            <td class="col-md-1 text-center">$26</td>
                                            <td class="col-md-1 text-center">$26</td>

                                        </tr>
                                        <tr class="small">
                                            <td class="col-md-9"><em>Lebanese Cabbage Salad</em></h4></td>
                                            <td class="col-md-1" style="text-align: center"> 1 </td>
                                            <td class="col-md-1 text-center">$8</td>
                                            <td class="col-md-1 text-center">$8</td>
                                            <td class="col-md-1 text-center">$26</td>
                                            <td class="col-md-1 text-center">$26</td>
                                            <td class="col-md-1 text-center">$26</td>
                                            <td class="col-md-1 text-center">$26</td>
                                            <td class="col-md-1 text-center">$26</td>
                                            <td class="col-md-1 text-center">$26</td>
                                            <td class="col-md-1 text-center">$26</td>
                                            <td class="col-md-1 text-center">$26</td>
                                            <td class="col-md-1 text-center">$26</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <!-- /.Second row -->
                </div>
            </section>
</div>   
<script>
$('.datepicker').pickadate({
weekdaysShort: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
showMonthsShort: true
editable: true
})
</script>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('header_report', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\dev-invoice\resources\views/print/report.blade.php ENDPATH**/ ?>