<?php $__env->startSection('content'); ?>

<h1>Hello</h1>
<button type="button" class="btn btn-outline bg-teal-400 border-teal-400 text-teal-800 btn-icon rounded-round legitRipple mr-1 waves-effect waves-light" data-toggle="modal" data-target="#modal_theme_success" id="btn-edit"><i class="icon-printer2"></i></button>

<div id="modal_theme_success" class="modal fade" tabindex="-1" style="display: none;" aria-hidden="true" data-backdrop="static"  >
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <?php echo $__env->make('print.invoiceprint', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\dev-invoice\resources\views/print/index.blade.php ENDPATH**/ ?>