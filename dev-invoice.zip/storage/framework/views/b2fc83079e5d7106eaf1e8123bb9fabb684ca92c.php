<style>
#tbl_paymentHistory td{
    padding:5px;
}
#tbl_paymentHistory th{
    font-weight:400;
    font-size:12px;
}
.plabel{
    top: 18px!important;
    z-index: 1!important;
}
.md-top-2{
    top:2px;
}
.Prow{
    box-shadow: 0 1px 3px rgba(0,0,0,.12), 0 1px 2px rgba(0,0,0,.24);
    border: 1px solid #ddd;
}
</style>
<?php
    if(!$payments_history->isEmpty()):
        $current_price = $payments_history->last()->current_balance;
    else:
        $current_price = $amount;
    endif
?>

<h4 class="font-weight-bold text-uppercase mb-0 mt-3">Payment Invoice</h4>
<span>Invoice Number: </span> <span class="invoice-number"></span>
<div class="p-3">
    <div class="card">
        <div class="card-header bg-info header-elements-inline p-2">
            <h6 class="card-title font-weight-semibold font-weight-bold">Create Payment: Balance Owed $ <?php echo e($current_price); ?></h6>
            <div class="header-elements">
                <div class="list-icons">
                    <a class="list-icons-item" data-action="collapse"></a>
                </div>
            </div>
        </div>
        
        <?php if( $current_price > 0): ?>
            <div class="card-body p-2" style="">
                <form method="post" action="<?php echo e(action('Invoice_airticket_listController@store_payment')); ?>">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="invoice_id" value="<?php echo e($id); ?>">
                    <div class="row">
                        <div class="col">
                            <!-- Medium input -->
                            <div class="md-form text-left md-top-2">
                                <input type="number" min="1" max="<?php echo e($current_price); ?>" id="p_paymentPrice" class="form-control font-weight-bold" name="payment_price" value="0.00" step="0.01">
                                <label for="p_paymentPrice" class="text-nowrap active">Payment Price</label>
                            </div>
                        </div>
                        <div class="col">
                            <div class="md-form text-left">
                                <input type="date" id="p_paymentDate" class="form-control font-weight-bold" name="payment_date" value="<?php echo date('Y-m-d'); ?>">
                                <label for="p_paymentDate" class="text-nowrap active plabel">Payment Date</label>
                            </div>
                        </div>
                        <div class="col">
                            
                            <!--Blue select-->
                            <div class="md-form text-left">
                                <select class="mdb-select md-form colorful-select dropdown-primary" id="P_payment_method" name="payment_method">
                                    <?php $__currentLoopData = $payment_method; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($method->id); ?>" ><?php echo e($method->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <label for="P_payment_method" class="text-nowrap active plabel" style="font-size:13px">Payment Method</label>
                            </div>
                            

                        </div>
                        <div class="col">
                            <div class="md-form text-left md-top-2">
                                <input type="text" id="payment_status" class="form-control font-weight-bold" name="payment_status" value="pay off" >
                                <label for="payment_status" class="text-nowrap active">Payment Status</label>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="md-form text-left m-0">
                                <input type="text" id="p_paymentDescription" class="form-control font-weight-bold" name="payment_description" value=" " >
                                <label for="p_paymentDescription" class="text-nowrap active">Payment Description</label>
                            </div>  
                        </div>
                        <div class="col-lg-12">
                            <button type="submit" class="btn btn-success legitRipple waves-effect waves-light">Save Change<i class="icon-circle-right2 ml-2"></i></button>
                        </div>
                    </div>
                </form>
            </div>
        
        <?php endif; ?>
    </div>

    
    
    <h6 class="text-left col-lg-12 font-weight-bold pl-0">Paymenet History</h6>
        <table class="table border table-create table-bordered" id="tbl_paymentHistory">
            <tr class="table-active table-border-double text-center">
                <td>No</td>
                <th>Previous Balnace</th>
                <th>Repay</th>
                <th>Balance Owed</th>
                <th>Repay Date</th>
                <th> Method</th>
                <th> Status</th>
                <th> Description</th>
                <th>Setting</th>
            </tr>
            <?php if(!$payments_history->isEmpty()): ?>
                <?php $__currentLoopData = $payments_history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr class="font-weight-bold">
                    <td><?php echo e($loop->iteration); ?></td>
                    <td>$ <?php echo e(number_format($history->previous_balance,2)); ?></td>
                    <td>$ <?php echo e(number_format($history->new_payment,2)); ?></td>
                    <td>$ <?php echo e(number_format($history->current_balance,2)); ?></td>
                    <td><?php echo e(date('d M Y',strtotime($history->issue_date))); ?></td>
                    <td><?php echo e($history->payment_method[0]->name); ?></td>
                    <td><?php echo e($history->status); ?></td>
                    <td><?php echo e($history->description); ?></td>
                    <td>
                        <?php if(count($payments_history) == $loop->iteration): ?>
                            <span data-toggle="tooltip" data-placement="top" data-original-title="Edit Invoice">
                                <button type="button" class="btn btn-sm btn-outline bg-info-400 border-info-400 text-info-800 btn-icon rounded-round legitRipple mr-1 waves-effect waves-light modal2" data-toggle="modal" data-target="#modal_paymentEdit" id="btn-edit" value="<?php echo e($history->id); ?>">
                                    <i class="icon-quill4"></i>
                                </button>
                            </span>
                            <span data-toggle="tooltip" data-placement="top" data-original-title="Edit Invoice">
                                <button type="button" class="btn btn-sm btn-outline bg-danger-400 border-danger-400 text-danger-800 btn-icon rounded-round legitRipple mr-1 waves-effect waves-light" data-toggle="modal" data-target="#modal_paymentDelete" id="btn-delete" value="<?php echo e($history->id); ?>">
                                    <i class="icon-trash"></i>
                                </button>
                            </span>
                        <?php else: ?>
                            --
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <tr>
                    <td colspan=11 class="p-3">No Payment Record...</td>
                </tr>
            <?php endif; ?>;
        </table>


    <div class="modal-footer pt-5 pr-0">
            <div class="form-group text-center">
                <button class="btn btn-danger legitRipple waves-effect waves-light modal_modal_close" type="button" data-dismiss="modal">Cancel</button>
            </div>
        </div>
</div><?php /**PATH C:\wamp64\www\dev-invoice\resources\views/invoice_airticket_list/payment.blade.php ENDPATH**/ ?>